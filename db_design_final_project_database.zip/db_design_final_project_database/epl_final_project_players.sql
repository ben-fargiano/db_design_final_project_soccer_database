-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: epl_final_project
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `players`
--

DROP TABLE IF EXISTS `players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `players` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) NOT NULL,
  `position` varchar(45) DEFAULT NULL,
  `injured` tinyint(1) DEFAULT '0',
  `height_centimeters` int DEFAULT NULL,
  `weight_kilograms` int DEFAULT NULL,
  `strongfoot` varchar(45) DEFAULT NULL,
  `birth_year` int DEFAULT NULL,
  `height` int DEFAULT NULL,
  `weight` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `enumerated_strongfoot` (`strongfoot`),
  CONSTRAINT `enumerated_strongfoot` FOREIGN KEY (`strongfoot`) REFERENCES `strongfeet` (`strongfoot`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `players`
--

LOCK TABLES `players` WRITE;
/*!40000 ALTER TABLE `players` DISABLE KEYS */;
INSERT INTO `players` VALUES (1,'Bernd','Leno','GK',0,NULL,NULL,'right',NULL,NULL,NULL),(2,'Kieran','Tierney','LB',0,NULL,NULL,'left',NULL,NULL,NULL),(3,'David','Luiz','CB',0,NULL,NULL,'right',NULL,NULL,NULL),(4,'Bukayo','Saka','LM',0,NULL,NULL,NULL,NULL,NULL,NULL),(5,'Nicolas','Pepe','RM',0,NULL,NULL,NULL,NULL,NULL,NULL),(6,'Eddie','Nketiah','RS',0,NULL,NULL,NULL,NULL,NULL,NULL),(7,NULL,'Willian','RM',1,175,NULL,NULL,NULL,NULL,NULL),(8,'Pierre-Emerick','Aubameyang','CF',0,195,80,NULL,NULL,NULL,NULL),(9,'Alexandre','Lacazette','CF',0,NULL,75,NULL,NULL,NULL,NULL),(10,'Granit','Xhaka','CM',0,NULL,NULL,'both',NULL,NULL,NULL),(11,'Thomas','Partey','CM',0,NULL,NULL,NULL,NULL,NULL,NULL),(12,'Dani','Ceballos','CM',0,NULL,NULL,NULL,NULL,NULL,NULL),(13,'Rob','Holding','CB',0,NULL,NULL,NULL,NULL,NULL,NULL),(14,'Tom','Heaton','GK',0,NULL,80,NULL,NULL,NULL,NULL),(15,'Emiliano','Martinez','GK',0,NULL,NULL,NULL,NULL,NULL,NULL),(16,'Ezri','Konsa','CB',0,NULL,NULL,NULL,NULL,NULL,NULL),(17,'Matt','Targett','LB',0,NULL,NULL,NULL,NULL,NULL,NULL),(18,'Ahmed','El Mohamady','CB',0,NULL,NULL,NULL,NULL,NULL,NULL),(19,'Tyrone','Mings','CB',0,NULL,NULL,NULL,NULL,NULL,NULL),(20,'Matthew','Cash','RB',0,NULL,NULL,NULL,NULL,NULL,NULL),(21,'John','McGinn','CAM',0,NULL,NULL,NULL,NULL,NULL,NULL),(22,'Jack','Grealish','LM',0,NULL,NULL,NULL,NULL,NULL,NULL),(23,'Douglas','Luiz','CDM',0,NULL,NULL,NULL,NULL,NULL,NULL),(24,NULL,'Trezeguet','CM',0,NULL,NULL,'right',NULL,NULL,NULL),(25,'Ollie','Watkins','CF',0,NULL,76,NULL,NULL,NULL,NULL),(26,'Bertrand','Traore','RM',0,NULL,NULL,NULL,NULL,NULL,NULL),(27,'Jacob','Ramsey','LM',0,NULL,NULL,NULL,NULL,NULL,NULL),(28,'Thomas','McGill','GK',0,NULL,NULL,NULL,NULL,NULL,NULL),(29,'Adam','Webster','CB',1,NULL,NULL,NULL,NULL,NULL,NULL),(30,'Tariq','Lamptey','LB',0,NULL,NULL,NULL,NULL,NULL,NULL),(31,'Lewis','Dunk','CB',0,NULL,NULL,NULL,NULL,NULL,NULL),(32,'Dan','Burn','CB',0,NULL,NULL,NULL,NULL,NULL,NULL),(33,'Yves','Bissouma','CM',0,NULL,NULL,NULL,NULL,NULL,NULL),(34,'Pascal','Gross','CM',0,NULL,NULL,NULL,NULL,NULL,NULL),(35,'Adam','Lallana','RM',0,NULL,NULL,'right',NULL,NULL,NULL),(36,'Solly','March','LM',0,NULL,NULL,NULL,NULL,NULL,NULL),(37,'Neal','Maupay','CF',0,NULL,NULL,NULL,NULL,NULL,NULL),(38,'Leandro','Trossard','LM',0,NULL,NULL,NULL,NULL,NULL,NULL),(39,'Aaron','Connolly','RS',0,NULL,NULL,NULL,NULL,NULL,NULL),(40,'Danny','Welbeck','LS',1,NULL,NULL,NULL,NULL,NULL,NULL),(41,'Nick','Pope','GK',0,NULL,NULL,NULL,NULL,NULL,NULL),(42,'Matthew','Lowton','CB',0,NULL,NULL,NULL,NULL,NULL,NULL),(43,'James','Tarkowski','RB',0,NULL,NULL,NULL,NULL,NULL,NULL),(44,'Ben','Mee','CB',0,NULL,NULL,NULL,NULL,NULL,NULL),(45,'Kevin','Long','LB',0,NULL,NULL,NULL,NULL,NULL,NULL),(46,'Jack','Cork','CM',0,NULL,NULL,NULL,NULL,NULL,NULL),(47,'Johann','Gudmundsson','CM',0,NULL,NULL,NULL,NULL,NULL,NULL),(48,'Robbie','Brady','CM',1,NULL,NULL,NULL,NULL,NULL,NULL),(49,'Dwight','McNeil','CAM',0,NULL,NULL,NULL,NULL,NULL,NULL),(50,'Chris','Wood','CF',0,NULL,NULL,NULL,NULL,NULL,NULL),(51,'Jay','Rodriguez','RS',0,NULL,NULL,NULL,NULL,NULL,NULL),(52,'Matej','Vydra','LS',0,NULL,NULL,NULL,NULL,NULL,NULL),(53,'Edouard','Mendy','GK',0,NULL,NULL,NULL,NULL,NULL,NULL),(54,'Antonio','Rudiger','CB',0,NULL,NULL,NULL,NULL,NULL,NULL),(55,'Marcos','Alonso','RB',0,NULL,NULL,NULL,NULL,NULL,NULL),(56,'Reece','James','RB',0,NULL,NULL,NULL,NULL,NULL,NULL),(57,'Ben','Chilwell','LB',0,NULL,NULL,'left',NULL,NULL,NULL),(58,'Thiago','Silva','CB',0,NULL,NULL,'right',NULL,NULL,NULL),(59,'N\'Golo','Kante','CDM',0,NULL,NULL,NULL,NULL,NULL,NULL),(60,'Mateo','Kovacic','CM',0,NULL,NULL,NULL,NULL,NULL,NULL),(61,'Mason','Mount','CAM',0,NULL,NULL,'right',NULL,NULL,NULL),(62,'Christian','Pulisic','RM',0,NULL,NULL,'right',1998,NULL,NULL),(63,'Timo','Werner','RS',0,NULL,NULL,NULL,NULL,NULL,NULL),(64,'Tammy','Abraham','LS',0,NULL,NULL,NULL,1997,NULL,NULL),(65,'Olivier','Giroud','CF',0,NULL,NULL,'left',NULL,NULL,NULL),(66,'Vicente','Guaita','GK',0,NULL,NULL,NULL,NULL,NULL,NULL),(67,'Patrick','van Aanholt','CB',0,NULL,NULL,NULL,NULL,NULL,NULL),(68,'Mamadou','Sakho','CB',0,NULL,NULL,NULL,NULL,NULL,NULL),(69,'Tyrick','Mitchell','RB',0,NULL,NULL,NULL,1997,NULL,NULL),(70,'Andros','Townsend','LM',0,NULL,NULL,NULL,NULL,NULL,NULL),(71,'Jeffrey','Schlupp','CM',0,NULL,NULL,NULL,NULL,NULL,NULL),(72,'Jordan','Ayew','CF',0,NULL,NULL,NULL,NULL,NULL,NULL),(73,'Wilfried','Zaha','LS',0,NULL,NULL,NULL,NULL,NULL,NULL),(74,'Christian','Benteke','RS',0,NULL,NULL,NULL,NULL,NULL,NULL),(75,'Jordan','Pickford','GK',0,NULL,NULL,NULL,NULL,NULL,NULL),(76,'Lucas','Digne','LB',0,NULL,NULL,NULL,NULL,NULL,NULL),(77,'Yerry','Mina','CB',0,NULL,NULL,NULL,NULL,NULL,NULL),(78,'Gylfi','Sigurdsson','CM',0,NULL,NULL,NULL,NULL,NULL,NULL),(79,NULL,'Richarlison','LS',0,NULL,NULL,NULL,NULL,NULL,NULL),(80,'Dominic','Calvert-Lewin','CF',0,NULL,NULL,NULL,NULL,NULL,NULL),(81,'James','Rodriguez','LM',0,NULL,NULL,NULL,NULL,NULL,NULL),(82,'Illan','Meslier','GK',0,NULL,NULL,NULL,NULL,NULL,NULL),(83,'Luke','Ayling','LB',0,NULL,NULL,NULL,NULL,NULL,NULL),(84,'Ezgjan','Alioski','LM',0,NULL,NULL,NULL,NULL,NULL,NULL),(85,'Stuart','Dallas','CM',0,NULL,NULL,NULL,NULL,NULL,NULL),(86,'Jack','Harrison','CM',0,NULL,NULL,NULL,NULL,NULL,NULL),(87,'Patrick','Bamford','CF',0,NULL,NULL,NULL,NULL,NULL,NULL),(88,NULL,'Raphinha','RM',0,NULL,NULL,NULL,NULL,NULL,NULL),(89,'Kasper','Schmeichel','GK',0,NULL,NULL,NULL,NULL,NULL,NULL),(90,'James','Justin','RB',0,NULL,NULL,NULL,NULL,NULL,NULL),(91,'Jonny','Evans','CB',0,NULL,NULL,NULL,NULL,NULL,NULL),(92,'Daniel','Amartey','CM',0,NULL,NULL,NULL,NULL,NULL,NULL),(93,'James','Maddison','CAM',0,NULL,NULL,NULL,NULL,NULL,NULL),(94,'Youri','Tielemans','CDM',0,NULL,NULL,NULL,NULL,NULL,NULL),(95,'Harvey','Barnes','RM',0,NULL,NULL,NULL,NULL,NULL,NULL),(96,'Jamie','Vardy','CF',0,NULL,NULL,NULL,NULL,NULL,NULL),(97,'Kelechi','Iheanacho','CF',0,NULL,NULL,NULL,NULL,NULL,NULL),(98,'Alisson','Becker','GK',0,NULL,NULL,NULL,NULL,NULL,NULL),(99,'Virgil','van Dijk','CB',1,NULL,NULL,NULL,NULL,NULL,NULL),(100,'Andy','Robertson','LB',0,NULL,NULL,NULL,NULL,NULL,NULL),(101,'Trent','Alexander-Arnold','RB',0,NULL,NULL,NULL,NULL,NULL,NULL),(102,NULL,'Fabinho','CDM',0,NULL,NULL,NULL,NULL,NULL,NULL),(103,'Roberto','Firmino','CF',0,NULL,NULL,NULL,NULL,NULL,NULL),(104,'Mohamed','Salah','RM',0,NULL,NULL,NULL,NULL,NULL,NULL),(105,'Sadio','Mane','LM',0,NULL,NULL,NULL,NULL,NULL,NULL),(106,'Diogo','Jota','CF',0,NULL,NULL,NULL,NULL,NULL,NULL),(107,NULL,'Casemiro','CDM',0,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `players` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-23 14:10:27
