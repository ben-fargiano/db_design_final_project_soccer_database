package com.example.springtemplate.models;

public enum Strongfoot {
    left,
    right,
    both
}
